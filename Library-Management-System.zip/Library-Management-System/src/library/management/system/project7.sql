-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 31, 2022 at 04:46 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project7`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `username` varchar(20) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `sec_q` varchar(25) DEFAULT NULL,
  `sec_ans` varchar(25) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`username`, `name`, `password`, `sec_q`, `sec_ans`) VALUES
('Adi@', 'Aryan', '123', 'Your Lucky Number?', '2'),
('@Manav', 'Manav Birje', '898', 'Your NickName?', 'Sonu'),
('@kinjale', 'Prathamesh Kinjale', '456', 'Your child SuperHero?', 'Salman Khan'),
('@Gopal', 'Gopal Wagh', '888', 'Your childhood Name ?', 'Monu'),
('@Krish', 'Krish Savgave', '555', 'Your NickName?', 'Krishna'),
('@SAKSHI', 'Sakshi Thorbole', '2414', 'Your Lucky Number?', '24'),
('@Aryan', 'Aryan Thorbole', '2414', 'Your Lucky Number?', '24');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `book_id` varchar(10) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `publisher` varchar(30) DEFAULT NULL,
  `edition` varchar(10) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `pages` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `name`, `isbn`, `publisher`, `edition`, `price`, `pages`) VALUES
('993', 'SQL', '25889', 'Arihent', '1', '2000', '500'),
('71', 'Java', '66666', 'Stanley', '2', '5000', '1000'),
('881', 'SQL', '5678', 'Harsh Savgave', '3', '1500', '100'),
('650', 'Overcome Failure', '12345', 'Aishwarya Throbole', '2', '5000', '100'),
('658', 'BELIEVE IN YOURSELF', '555', 'Harsh Savgave', '2', '500', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `issuebook`
--

DROP TABLE IF EXISTS `issuebook`;
CREATE TABLE IF NOT EXISTS `issuebook` (
  `book_id` varchar(10) DEFAULT NULL,
  `student_id` varchar(10) DEFAULT NULL,
  `bname` varchar(40) DEFAULT NULL,
  `sname` varchar(40) DEFAULT NULL,
  `course` varchar(20) DEFAULT NULL,
  `branch` varchar(10) DEFAULT NULL,
  `dateOfIssue` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `returnbook`
--

DROP TABLE IF EXISTS `returnbook`;
CREATE TABLE IF NOT EXISTS `returnbook` (
  `book_id` varchar(10) DEFAULT NULL,
  `student_id` varchar(10) DEFAULT NULL,
  `bname` varchar(40) DEFAULT NULL,
  `sname` varchar(40) DEFAULT NULL,
  `course` varchar(20) DEFAULT NULL,
  `branch` varchar(10) DEFAULT NULL,
  `dateOfIssue` varchar(30) DEFAULT NULL,
  `dateOfReturn` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returnbook`
--

INSERT INTO `returnbook` (`book_id`, `student_id`, `bname`, `sname`, `course`, `branch`, `dateOfIssue`, `dateOfReturn`) VALUES
('993', '2233', 'SQL', 'Pratibha Khoche', 'B.E', 'Mechanical', 'Jan 6, 2022', 'Jan 6, 2022'),
('71', '2856', 'Java', 'Sakshi Thorbole', 'B.E', 'IT', 'Jan 27, 2022', 'Jan 29, 2022'),
('71', '2233', 'Java', 'Pratibha Khoche', 'B.E', 'Mechanical', 'Jan 28, 2022', 'Jan 28, 2022');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` varchar(10) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  `father` varchar(25) DEFAULT NULL,
  `course` varchar(10) DEFAULT NULL,
  `branch` varchar(10) DEFAULT NULL,
  `year` varchar(10) DEFAULT NULL,
  `semester` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `name`, `father`, `course`, `branch`, `year`, `semester`) VALUES
('2233', 'Pratibha Khoche', 'Shrinivas Khoche', 'B.E', 'Mechanical', 'First', '2nd'),
('5303', 'Sangeeta Patil', 'Suraj Patil', 'MBA', 'IT', 'First', '2nd'),
('1983', 'Gopal Wagh', 'Sujit Wagh', 'M.Sc', 'Mechanical', 'Four', '7th'),
('2856', 'Sakshi Thorbole', 'Raj Thorbole', 'B.E', 'IT', 'Second', '3rd'),
('2822', 'Sonu Thorbole', 'Raj Thorbole', 'B.E', 'Mechanical', 'Second', '4th');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
